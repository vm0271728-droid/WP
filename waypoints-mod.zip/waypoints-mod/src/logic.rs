//! Pure logic (no SDK): testable on the host with `rustc --test src/logic.rs`.

pub const COLORS: [(&str, u32); 9] = [
    ("белый", 0xFFFFFF),
    ("зелёный", 0x55FF55),
    ("красный", 0xFF5555),
    ("синий", 0x5555FF),
    ("жёлтый", 0xFFFF55),
    ("бирюзовый", 0x55FFFF),
    ("пурпурный", 0xFF55FF),
    ("золотой", 0xFFAA00),
    ("серый", 0xAAAAAA),
];
pub const DEATH_COLOR: usize = 2;
pub const DEATH_NAME: &str = "Смерть";
pub const DEATH_RADIUS: f64 = 5.0;
pub const MAX_DEATHS: usize = 5;
pub const MAX_WAYPOINTS: usize = 200;

#[derive(Clone, Debug, PartialEq)]
pub struct Wp {
    pub name: String,
    pub x: i32,
    pub y: i32,
    pub z: i32,
    pub dim: String,
    pub color: usize,
    pub death: bool,
}

#[derive(Clone, Debug, PartialEq)]
pub struct World {
    pub id: u32,
    pub name: String,
    pub dim: String,
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub gt: u64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Cfg {
    pub size: u8, // 0..=2
    pub show: bool,
    pub hover: bool,
    pub death: bool,
    pub fov: u32,
    pub new_color: usize,
    pub scale: bool,
}
impl Default for Cfg {
    fn default() -> Self {
        Cfg { size: 1, show: true, hover: true, death: true, fov: 70, new_color: 0, scale: true }
    }
}

pub fn clean(s: &str) -> String {
    let t: String = s.chars().map(|c| if c.is_control() { ' ' } else { c }).collect();
    t.trim().chars().take(24).collect()
}

pub fn short_dim(d: &str) -> &str {
    match d {
        "minecraft:overworld" => "Верхний мир",
        "minecraft:the_nether" => "Незер",
        "minecraft:the_end" => "Энд",
        other => other.trim_start_matches("minecraft:"),
    }
}

// ---------- persistence ----------
pub fn ser_wps(v: &[Wp]) -> String {
    v.iter()
        .map(|w| format!("{}\t{}\t{}\t{}\t{}\t{}\t{}\n", clean(&w.name), w.x, w.y, w.z, w.dim, w.color, w.death as u8))
        .collect()
}
pub fn parse_wps(s: &str) -> Vec<Wp> {
    s.lines()
        .filter_map(|l| {
            let p: Vec<&str> = l.split('\t').collect();
            if p.len() < 7 {
                return None;
            }
            Some(Wp {
                name: clean(p[0]),
                x: p[1].parse().ok()?,
                y: p[2].parse().ok()?,
                z: p[3].parse().ok()?,
                dim: p[4].to_string(),
                color: p[5].parse::<usize>().ok().filter(|c| *c < COLORS.len()).unwrap_or(0),
                death: p[6] == "1",
            })
        })
        .take(MAX_WAYPOINTS)
        .collect()
}
pub fn ser_worlds(v: &[World]) -> String {
    v.iter()
        .map(|w| format!("{}\t{}\t{}\t{}\t{}\t{}\t{}\n", w.id, clean(&w.name), w.dim, w.x, w.y, w.z, w.gt))
        .collect()
}
pub fn parse_worlds(s: &str) -> Vec<World> {
    s.lines()
        .filter_map(|l| {
            let p: Vec<&str> = l.split('\t').collect();
            if p.len() < 7 {
                return None;
            }
            Some(World {
                id: p[0].parse().ok()?,
                name: clean(p[1]),
                dim: p[2].to_string(),
                x: p[3].parse().ok()?,
                y: p[4].parse().ok()?,
                z: p[5].parse().ok()?,
                gt: p[6].parse().ok()?,
            })
        })
        .collect()
}
pub fn ser_cfg(c: &Cfg) -> String {
    format!("{} {} {} {} {} {} {}", c.size, c.show as u8, c.hover as u8, c.death as u8, c.fov, c.new_color, c.scale as u8)
}
pub fn parse_cfg(s: &str) -> Cfg {
    let p: Vec<&str> = s.split_whitespace().collect();
    let d = Cfg::default();
    if p.len() < 6 {
        return d;
    }
    Cfg {
        size: p[0].parse::<u8>().ok().filter(|v| *v <= 2).unwrap_or(d.size),
        show: p[1] != "0",
        hover: p[2] != "0",
        death: p[3] != "0",
        fov: p[4].parse::<u32>().ok().map(|v| v.clamp(30, 110)).unwrap_or(d.fov),
        new_color: p[5].parse::<usize>().ok().filter(|c| *c < COLORS.len()).unwrap_or(0),
        scale: p.get(6).map_or(true, |v| *v != "0"),
    }
}

// ---------- which world is this? ----------
/// The API gives no world/server id, so a world is recognised by where and when the
/// player left it: on rejoin they stand where they quit (same dimension, within `R`
/// blocks) and the world clock has not gone back.
pub const MATCH_R: f64 = 24.0;
pub fn match_world(worlds: &[World], active: Option<u32>, dim: &str, p: (f64, f64, f64), gt: u64) -> Option<u32> {
    // Same session, dimension change (portal): the clock just kept running.
    if let Some(a) = active.and_then(|id| worlds.iter().find(|w| w.id == id)) {
        if gt + 20 >= a.gt && gt <= a.gt + 600 {
            return Some(a.id);
        }
    }
    worlds
        .iter()
        .filter(|w| w.dim == dim && gt + 20 >= w.gt)
        .map(|w| (w, ((w.x - p.0).powi(2) + (w.y - p.1).powi(2) + (w.z - p.2).powi(2)).sqrt()))
        .filter(|(_, d)| *d <= MATCH_R)
        .min_by(|a, b| a.1.partial_cmp(&b.1).unwrap())
        .map(|(w, _)| w.id)
}

// ---------- labels ----------
pub fn upper(c: char) -> char {
    match c {
        'a'..='z' => c.to_ascii_uppercase(),
        'а'..='я' => char::from_u32(c as u32 - 32).unwrap_or(c),
        'ё' => 'Ё',
        _ => c,
    }
}
/// First and last letter of the name ("Дом" -> "ДМ"); one letter for a one-letter name.
pub fn label(name: &str) -> String {
    let cs: Vec<char> = name.chars().filter(|c| !c.is_whitespace()).collect();
    match cs.len() {
        0 => "?".into(),
        1 => upper(cs[0]).to_string(),
        n => format!("{}{}", upper(cs[0]), upper(cs[n - 1])),
    }
}

// ---------- projection ----------
/// Screen position (GUI px) and distance of block `t` for a camera at `eye`.
/// Minecraft: yaw 0 looks +Z, 90 looks -X; pitch positive looks down; `fov` is vertical.
pub fn project(eye: (f64, f64, f64), yaw: f64, pitch: f64, fov: f64, gui: (f64, f64), t: (f64, f64, f64)) -> Option<(f64, f64, f64)> {
    let (yr, pr) = (yaw.to_radians(), pitch.to_radians());
    let f = (-yr.sin() * pr.cos(), -pr.sin(), yr.cos() * pr.cos());
    let r = (-yr.cos(), 0.0, -yr.sin());
    let u = (r.1 * f.2 - r.2 * f.1, r.2 * f.0 - r.0 * f.2, r.0 * f.1 - r.1 * f.0);
    let d = (t.0 - eye.0, t.1 - eye.1, t.2 - eye.2);
    let dot = |a: (f64, f64, f64)| a.0 * d.0 + a.1 * d.1 + a.2 * d.2;
    let (cz, cx, cy) = (dot(f), dot(r), dot(u));
    if cz < 0.1 {
        return None;
    }
    let th = (fov.to_radians() / 2.0).tan();
    let aspect = gui.0 / gui.1;
    let sx = gui.0 / 2.0 + (cx / cz) / (th * aspect) * (gui.0 / 2.0);
    let sy = gui.1 / 2.0 - (cy / cz) / th * (gui.1 / 2.0);
    Some((sx, sy, (d.0 * d.0 + d.1 * d.1 + d.2 * d.2).sqrt()))
}

/// Marker size factor by distance: ~1.75 right next to it, ~1.0 at 30 blocks, ~0.65 far away.
pub fn scale_for(d: f64) -> f64 {
    (0.6 + 1.15 / (1.0 + d / 28.0)).clamp(0.62, 1.75)
}
/// Shortest signed angle difference in degrees, in [-180, 180).
pub fn angle_diff(a: f64, b: f64) -> f64 {
    (a - b + 540.0).rem_euclid(360.0) - 180.0
}

// ---------- death points ----------
pub fn near_death(p: (f64, f64, f64), dim: &str, w: &Wp) -> bool {
    w.death && w.dim == dim && {
        let d = (w.x as f64 + 0.5 - p.0, w.y as f64 - p.1, w.z as f64 + 0.5 - p.2);
        (d.0 * d.0 + d.1 * d.1 + d.2 * d.2).sqrt() <= DEATH_RADIUS
    }
}

// ---------- hints ----------
pub fn dist(a: &str, b: &str) -> usize {
    let (a, b): (Vec<char>, Vec<char>) = (a.chars().collect(), b.chars().collect());
    let mut prev: Vec<usize> = (0..=b.len()).collect();
    for i in 1..=a.len() {
        let mut cur = vec![i];
        for j in 1..=b.len() {
            let c = if a[i - 1] == b[j - 1] { 0 } else { 1 };
            cur.push((prev[j] + 1).min(cur[j - 1] + 1).min(prev[j - 1] + c));
        }
        prev = cur;
    }
    prev[b.len()]
}
pub fn suggest<'a>(word: &str, options: &[&'a str]) -> Option<&'a str> {
    let w = word.to_lowercase();
    options
        .iter()
        .map(|o| (*o, if o.starts_with(&w) && !w.is_empty() { 0 } else { dist(&w, o) }))
        .filter(|(_, d)| *d <= 2)
        .min_by_key(|(_, d)| *d)
        .map(|(o, _)| o)
}
pub fn find_color(word: &str) -> Option<usize> {
    let w = word.to_lowercase().replace('ё', "е");
    if let Ok(n) = w.parse::<usize>() {
        return (1..=COLORS.len()).contains(&n).then(|| n - 1);
    }
    COLORS.iter().position(|(n, _)| n.replace('ё', "е") == w)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn labels() {
        assert_eq!(label("Дом"), "ДМ");
        assert_eq!(label("a"), "A");
        assert_eq!(label("ёж"), "ЁЖ");
        assert_eq!(label("Моя база"), "МА");
    }
    #[test]
    fn projection_center_and_sides() {
        let eye = (0.0, 0.0, 0.0);
        let g = (400.0, 240.0);
        let (x, y, _) = project(eye, 0.0, 0.0, 70.0, g, (0.0, 0.0, 10.0)).unwrap();
        assert!((x - 200.0).abs() < 1e-6 && (y - 120.0).abs() < 1e-6);
        // facing +Z, -X is to the right
        let (x, _, _) = project(eye, 0.0, 0.0, 70.0, g, (-3.0, 0.0, 10.0)).unwrap();
        assert!(x > 200.0);
        // above is up (smaller y)
        let (_, y, _) = project(eye, 0.0, 0.0, 70.0, g, (0.0, 3.0, 10.0)).unwrap();
        assert!(y < 120.0);
        // behind
        assert!(project(eye, 0.0, 0.0, 70.0, g, (0.0, 0.0, -5.0)).is_none());
        // yaw 90 looks -X
        let (x, _, _) = project(eye, 90.0, 0.0, 70.0, g, (-10.0, 0.0, 0.0)).unwrap();
        assert!((x - 200.0).abs() < 1e-6);
        // pitch down 45: a block straight ahead at eye level is above centre
        let (_, y, _) = project(eye, 0.0, 45.0, 70.0, g, (0.0, 0.0, 10.0)).unwrap();
        assert!(y < 120.0);
    }
    #[test]
    fn worlds_are_told_apart() {
        let w = |id, x, gt| World { id, name: "w".into(), dim: "minecraft:overworld".into(), x, y: 64.0, z: 0.0, gt };
        let ws = vec![w(1, 100.0, 5000), w(2, 5000.0, 90000)];
        let d = "minecraft:overworld";
        assert_eq!(match_world(&ws, None, d, (101.0, 64.0, 0.0), 5100), Some(1));
        assert_eq!(match_world(&ws, None, d, (5003.0, 64.0, 2.0), 90500), Some(2));
        assert_eq!(match_world(&ws, None, d, (0.0, 64.0, 0.0), 30), None); // fresh world
        assert_eq!(match_world(&ws, None, d, (101.0, 64.0, 0.0), 100), None); // clock went back
        assert_eq!(match_world(&ws, None, "minecraft:the_nether", (101.0, 64.0, 0.0), 5100), None);
        assert_eq!(match_world(&ws, Some(1), "minecraft:the_nether", (12.0, 70.0, 3.0), 5200), Some(1));
    }
    #[test]
    fn scale_and_angles() {
        assert!(scale_for(2.0) > scale_for(30.0) && scale_for(30.0) > scale_for(300.0));
        assert!(scale_for(1e6) >= 0.62);
        assert!((angle_diff(359.0, 1.0) + 2.0).abs() < 1e-9);
        assert!((angle_diff(1.0, 359.0) - 2.0).abs() < 1e-9);
        assert_eq!(parse_cfg("1 1 1 1 70 0"), Cfg::default());
    }
    #[test]
    fn death_radius() {
        let w = Wp { name: "Смерть".into(), x: 10, y: 64, z: 10, dim: "d".into(), color: 2, death: true };
        assert!(near_death((10.5, 64.0, 14.0), "d", &w));
        assert!(!near_death((10.5, 64.0, 17.0), "d", &w));
        assert!(!near_death((10.5, 64.0, 10.0), "other", &w));
    }
    #[test]
    fn roundtrip_and_hints() {
        let v = vec![Wp { name: "Дом".into(), x: -1, y: 2, z: 3, dim: "minecraft:overworld".into(), color: 3, death: false }];
        assert_eq!(parse_wps(&ser_wps(&v)), v);
        assert_eq!(parse_cfg("garbage"), Cfg::default());
        assert_eq!(suggest("ad", &["add", "del"]), Some("add"));
        assert_eq!(suggest("dle", &["add", "del"]), Some("del"));
        assert_eq!(find_color("Зеленый"), Some(1));
        assert_eq!(find_color("2"), Some(1));
    }
}
