//! Waypoints for Horizon (Android fork, api 0.1): see README.md.
mod logic;

use horizon_mod_sdk::{
    game,
    render::{self, FillShape, Point, Rect, Shape, TextShape},
    storage,
    ui::{self, ButtonWidget, ListWidget, Screen, TextWidget, Widget},
    Mod, Registration,
};
use logic::*;

const SETTLE_TICKS: u64 = 40; // wait after joining until position and clock are real
const SAVE_EVERY: u64 = 10; // ticks between "where I am" saves
const MAX_SHOWN: usize = 48;
const SIZES: [(&str, f32); 3] = [("S", 14.0), ("M", 18.0), ("L", 22.0)];

const SUBCOMMANDS: [&str; 17] = [
    "menu", "add", "del", "list", "color", "default", "rename", "name", "size", "scale", "show", "hover", "death", "fov", "clear", "world", "help",
];

struct Waypoints {
    cfg: Cfg,
    worlds: Vec<World>,
    active: Option<u32>,
    wps: Vec<Wp>,
    // session
    in_world: bool,
    joined_tick: u64,
    resolved: bool,
    last_save: u64,
    dead: bool,
    toast_until: u64,
    toast: String,
    tick: u64,
    selected: Option<usize>,
    detail: Option<usize>,
    hovered_wp: Option<usize>,
    menu_open: bool,
    cam: Cam,
}

/// Camera smoothing: the game hands over the player a tick at a time, so between
/// changes the view is carried on at the speed it was last seen moving.
#[derive(Default)]
struct Cam {
    last: [f64; 5], // x y z yaw pitch
    vel: [f64; 5],
    since: f64,
    acc: f64,
    init: bool,
}
impl Cam {
    fn adjust(&mut self, p: &game::Player, dt: f64) -> game::Player {
        let cur = [p.x, p.y, p.z, p.yaw as f64, p.pitch as f64];
        self.acc += dt;
        if !self.init {
            self.init = true;
            self.last = cur;
        }
        let changed = cur.iter().zip(self.last.iter()).any(|(a, b)| (a - b).abs() > 1e-7);
        if changed {
            let span = self.acc.max(0.02);
            for i in 0..5 {
                let d = if i == 3 { angle_diff(cur[i], self.last[i]) } else { cur[i] - self.last[i] };
                self.vel[i] = if self.acc > 0.25 || d.abs() > 60.0 { 0.0 } else { d / span };
            }
            self.last = cur;
            self.since = 0.0;
            self.acc = 0.0;
        } else {
            self.since += dt;
        }
        let t = self.since.min(0.06);
        let mut q = p.clone();
        q.x += self.vel[0] * t;
        q.y += self.vel[1] * t;
        q.z += self.vel[2] * t;
        q.yaw = (p.yaw as f64 + self.vel[3] * t) as f32;
        q.pitch = (p.pitch as f64 + self.vel[4] * t).clamp(-90.0, 90.0) as f32;
        q
    }
}

fn get_text(key: &str) -> Option<String> {
    storage::get(key).map(|b| String::from_utf8_lossy(&b).into_owned())
}
fn put(key: &str, v: &str) {
    let _ = storage::set(key, v.as_bytes());
}
fn on_off(b: bool) -> &'static str {
    if b { "вкл" } else { "выкл" }
}
fn parse_bool(s: &str) -> Option<bool> {
    match s.to_lowercase().as_str() {
        "on" | "вкл" | "да" | "1" | "true" => Some(true),
        "off" | "выкл" | "нет" | "0" | "false" => Some(false),
        _ => None,
    }
}
fn color_list() -> String {
    COLORS.iter().enumerate().map(|(i, (n, _))| format!("{}={}", i + 1, n)).collect::<Vec<_>>().join(", ")
}

impl Waypoints {
    // ---------- storage ----------
    fn save_cfg(&self) {
        put("cfg2", &ser_cfg(&self.cfg));
    }
    fn save_worlds(&self) {
        put("idx", &ser_worlds(&self.worlds));
    }
    fn save_wps(&self) {
        if let Some(id) = self.active {
            put(&format!("w{id}"), &ser_wps(&self.wps));
        }
    }
    fn world_name(&self) -> String {
        self.active
            .and_then(|id| self.worlds.iter().find(|w| w.id == id))
            .map(|w| w.name.clone())
            .unwrap_or_else(|| "—".into())
    }
    fn activate(&mut self, id: u32) {
        self.active = Some(id);
        self.wps = get_text(&format!("w{id}")).map(|s| parse_wps(&s)).unwrap_or_default();
        self.selected = None;
        self.detail = None;
    }
    fn new_world(&mut self, name: Option<String>, dim: &str, p: (f64, f64, f64), gt: u64) -> u32 {
        let id = self.worlds.iter().map(|w| w.id).max().unwrap_or(0) + 1;
        let name = name.filter(|n| !n.is_empty()).unwrap_or_else(|| format!("Мир {id}"));
        self.worlds.push(World { id, name, dim: dim.into(), x: p.0, y: p.1, z: p.2, gt });
        self.save_worlds();
        self.activate(id);
        id
    }

    fn snapshot() -> Option<(game::Player, u64)> {
        let p = game::get_player()?;
        let gt = game::get_clock().map(|c| c.game_time).unwrap_or(0);
        Some((p, gt))
    }

    // ---------- waypoint ops ----------
    fn add(&mut self, name: String, color: usize, death: bool) -> Result<String, String> {
        let (p, _) = Self::snapshot().ok_or("Вы не в мире")?;
        if !self.resolved {
            return Err("Мир ещё определяется, подождите пару секунд".into());
        }
        if self.wps.len() >= MAX_WAYPOINTS {
            return Err(format!("Слишком много меток (максимум {MAX_WAYPOINTS})"));
        }
        let name = if name.is_empty() { format!("Метка {}", self.wps.iter().filter(|w| !w.death).count() + 1) } else { name };
        self.wps.push(Wp {
            name: name.clone(),
            x: p.x.floor() as i32,
            y: p.y.floor() as i32,
            z: p.z.floor() as i32,
            dim: p.dimension,
            color,
            death,
        });
        self.save_wps();
        Ok(format!("Метка «{name}» добавлена ({} {} {}), цвет: {}", p.x.floor(), p.y.floor(), p.z.floor(), COLORS[color].0))
    }
    /// `#3` / `3` or a name (case-insensitive).
    fn find(&self, key: &str) -> Option<usize> {
        let k = key.trim().trim_start_matches('#');
        if let Ok(n) = k.parse::<usize>() {
            if (1..=self.wps.len()).contains(&n) {
                return Some(n - 1);
            }
        }
        let l = k.to_lowercase();
        self.wps.iter().position(|w| w.name.to_lowercase() == l)
    }
    fn not_found(&self, key: &str) -> String {
        let names: Vec<&str> = self.wps.iter().map(|w| w.name.as_str()).collect();
        match suggest(key, &names) {
            Some(s) => format!("Метка «{key}» не найдена. Может, «{s}»? Список: /wp list"),
            None => format!("Метка «{key}» не найдена. Список: /wp list"),
        }
    }

    // ---------- commands ----------
    fn help(&self, topic: &str) -> String {
        match topic {
            "add" => "/wp add [имя] [цвет] — метка на ваших координатах. Пример: /wp add Дом красный. Цвета: /wp color".into(),
            "del" => "/wp del <имя|№> — удалить метку. Пример: /wp del Дом или /wp del 2 (номера: /wp list)".into(),
            "color" => format!("/wp color <имя|№> <цвет> — цвет метки. Цвета: {}", color_list()),
            "default" => format!("/wp default <цвет> — цвет новых меток. Цвета: {}", color_list()),
            "rename" => "/wp rename <имя|№> <новое имя>. Пример: /wp rename 1 Шахта".into(),
            "size" => "/wp size s|m|l — размер квадрата метки".into(),
            "scale" => "/wp scale on|off — метка меньше вдали и крупнее вблизи".into(),
            "name" => "/wp name <новое имя> — переименовать выбранную в меню метку или ту, на которую наведён прицел".into(),
            "show" => "/wp show on|off — показ меток на экране".into(),
            "hover" => "/wp hover on|off — имя и координаты при наведении прицела".into(),
            "death" => format!("/wp death on|off — запоминать точки смерти (макс. {MAX_DEATHS}); рядом, в радиусе {DEATH_RADIUS} блоков, точка удаляется сама"),
            "fov" => "/wp fov <30-110> — ваш FOV из настроек игры (по умолчанию 70), нужен для точного положения меток".into(),
            "clear" => "/wp clear да — удалить ВСЕ метки этого мира; /wp clear смерть — только точки смерти".into(),
            "world" => "/wp world — текущий мир; /wp world list|new [имя]|use <№|имя>|name <имя>|del <№>".into(),
            "list" => "/wp list — метки этого мира с номерами".into(),
            _ => "Команды /wp: (без аргументов — меню) · add · del · list · color · default · rename · name · size · scale · show · hover · death · fov · clear · world. Подробно: /wp help <команда>".into(),
        }
    }

    fn cmd_world(&mut self, rest: &str) -> Result<Option<String>, String> {
        let (sub, arg) = split1(rest);
        let (p, gt) = Self::snapshot().ok_or("Вы не в мире")?;
        let at = (p.x, p.y, p.z);
        match sub.as_str() {
            "" => Ok(Some(format!(
                "Мир: «{}» (меток: {}). Мир определяется автоматически по месту выхода; если ошибся: /wp world list, /wp world use <№>, /wp world new",
                self.world_name(),
                self.wps.len()
            ))),
            "list" => {
                let s: Vec<String> = self
                    .worlds
                    .iter()
                    .map(|w| format!("{}{}. {}", if Some(w.id) == self.active { "▶" } else { "" }, w.id, w.name))
                    .collect();
                Ok(Some(if s.is_empty() { "Миров пока нет".into() } else { s.join(" · ") }))
            }
            "new" => {
                let id = self.new_world(Some(clean(&arg)), &p.dimension, at, gt);
                self.resolved = true;
                Ok(Some(format!("Создан мир {id}: «{}» — список меток пуст", self.world_name())))
            }
            "use" => {
                let key = arg.trim().trim_start_matches('#').to_lowercase();
                let id = key
                    .parse::<u32>()
                    .ok()
                    .filter(|n| self.worlds.iter().any(|w| w.id == *n))
                    .or_else(|| self.worlds.iter().find(|w| w.name.to_lowercase() == key).map(|w| w.id))
                    .ok_or("Нет такого мира. Список: /wp world list")?;
                self.activate(id);
                self.resolved = true;
                self.stamp(&p, gt);
                Ok(Some(format!("Мир: «{}», меток: {}", self.world_name(), self.wps.len())))
            }
            "name" | "rename" => {
                let n = clean(&arg);
                if n.is_empty() {
                    return Err("Использование: /wp world name <новое имя>".into());
                }
                let id = self.active.ok_or("Мир ещё не определён")?;
                if let Some(w) = self.worlds.iter_mut().find(|w| w.id == id) {
                    w.name = n.clone();
                }
                self.save_worlds();
                Ok(Some(format!("Мир переименован: «{n}»")))
            }
            "del" => {
                let id: u32 = arg.trim().trim_start_matches('#').parse().map_err(|_| "Использование: /wp world del <№>".to_string())?;
                if Some(id) == self.active {
                    return Err("Нельзя удалить текущий мир".into());
                }
                if !self.worlds.iter().any(|w| w.id == id) {
                    return Err("Нет такого мира. Список: /wp world list".into());
                }
                self.worlds.retain(|w| w.id != id);
                storage::delete(&format!("w{id}"));
                self.save_worlds();
                Ok(Some(format!("Мир {id} удалён")))
            }
            other => Err(match suggest(other, &["list", "new", "use", "name", "del"]) {
                Some(s) => format!("Неизвестно «{other}». Может, «{s}»? {}", self.help("world")),
                None => self.help("world"),
            }),
        }
    }

    fn run(&mut self, args: &str) -> Result<Option<String>, String> {
        let (sub, rest) = split1(args);
        let sub = match sub.as_str() {
            "доб" | "добавить" | "new" => "add".to_string(),
            "удалить" | "rm" | "remove" => "del".to_string(),
            "список" | "ls" => "list".to_string(),
            "цвет" => "color".to_string(),
            "имя" => "rename".to_string(),
            "размер" => "size".to_string(),
            "мир" => "world".to_string(),
            "помощь" | "?" => "help".to_string(),
            "очистить" => "clear".to_string(),
            s => s.to_string(),
        };
        match sub.as_str() {
            "" | "menu" => {
                self.open_menu();
                Ok(None)
            }
            "help" => Ok(Some(self.help(rest.trim()))),
            "world" => self.cmd_world(&rest),
            "add" => {
                let mut words: Vec<&str> = rest.split_whitespace().collect();
                let mut color = self.cfg.new_color;
                if words.len() > 1 {
                    if let Some(c) = find_color(words[words.len() - 1]) {
                        color = c;
                        words.pop();
                    }
                }
                let name = clean(&words.join(" "));
                let m = self.add(name, color, false)?;
                Ok(Some(m))
            }
            "del" => {
                if rest.trim().is_empty() {
                    return Err(self.help("del"));
                }
                let i = self.find(&rest).ok_or_else(|| self.not_found(rest.trim()))?;
                let w = self.wps.remove(i);
                self.save_wps();
                Ok(Some(format!("Метка «{}» удалена", w.name)))
            }
            "list" => {
                if self.wps.is_empty() {
                    return Ok(Some("В этом мире меток нет. Добавить: /wp add Дом".into()));
                }
                let s: Vec<String> = self
                    .wps
                    .iter()
                    .enumerate()
                    .map(|(i, w)| format!("{}. {} ({} {} {}, {})", i + 1, w.name, w.x, w.y, w.z, short_dim(&w.dim)))
                    .collect();
                Ok(Some(format!("Мир «{}»: {}", self.world_name(), s.join(" · "))))
            }
            "color" | "default" => {
                let (a, b) = split1(&rest);
                if sub == "default" || (a.is_empty()) {
                    let word = if sub == "default" { rest.trim().to_string() } else { String::new() };
                    if word.is_empty() {
                        return Ok(Some(format!("Цвета: {}. Использование: {}", color_list(), self.help(&sub))));
                    }
                    let c = find_color(&word).ok_or_else(|| self.bad_color(&word))?;
                    self.cfg.new_color = c;
                    self.save_cfg();
                    return Ok(Some(format!("Цвет новых меток: {}", COLORS[c].0)));
                }
                let i = self.find(&a).ok_or_else(|| self.not_found(&a))?;
                if b.trim().is_empty() {
                    return Err(format!("Укажите цвет. Цвета: {}", color_list()));
                }
                let c = find_color(b.trim()).ok_or_else(|| self.bad_color(b.trim()))?;
                self.wps[i].color = c;
                self.save_wps();
                Ok(Some(format!("Метка «{}»: цвет {}", self.wps[i].name, COLORS[c].0)))
            }
            "rename" => {
                let (a, b) = split1(&rest);
                let n = clean(&b);
                if a.is_empty() || n.is_empty() {
                    return Err(self.help("rename"));
                }
                let i = self.find(&a).ok_or_else(|| self.not_found(&a))?;
                self.wps[i].name = n.clone();
                self.save_wps();
                Ok(Some(format!("Метка переименована: «{n}»")))
            }
            "size" => {
                let v = match rest.trim().to_lowercase().as_str() {
                    "s" | "м" | "мал" | "малый" => 0,
                    "m" | "с" | "ср" | "средний" => 1,
                    "l" | "б" | "бол" | "большой" => 2,
                    _ => return Err(self.help("size")),
                };
                self.cfg.size = v;
                self.save_cfg();
                Ok(Some(format!("Размер меток: {}", SIZES[v as usize].0)))
            }
            "name" => {
                let n = clean(&rest);
                if n.is_empty() {
                    return Err(self.help("name"));
                }
                let i = self
                    .detail
                    .or(self.selected)
                    .or(self.hovered_wp)
                    .filter(|i| *i < self.wps.len())
                    .ok_or("Выберите метку в меню /wp или наведите на неё прицел, либо /wp rename <№> <имя>")?;
                self.wps[i].name = n.clone();
                self.save_wps();
                Ok(Some(format!("Метка переименована: «{n}»")))
            }
            "show" | "hover" | "death" | "scale" => {
                let v = parse_bool(rest.trim()).ok_or_else(|| self.help(&sub))?;
                match sub.as_str() {
                    "show" => self.cfg.show = v,
                    "scale" => self.cfg.scale = v,
                    "hover" => self.cfg.hover = v,
                    _ => self.cfg.death = v,
                }
                self.save_cfg();
                Ok(Some(format!("{}: {}", sub, on_off(v))))
            }
            "fov" => {
                let v: u32 = rest.trim().parse().map_err(|_| self.help("fov"))?;
                self.cfg.fov = v.clamp(30, 110);
                self.save_cfg();
                Ok(Some(format!("FOV: {}", self.cfg.fov)))
            }
            "clear" => {
                match rest.trim().to_lowercase().as_str() {
                    "да" | "yes" | "all" | "все" => {
                        let n = self.wps.len();
                        self.wps.clear();
                        self.save_wps();
                        Ok(Some(format!("Удалено меток: {n}")))
                    }
                    "смерть" | "death" => {
                        let n = self.wps.len();
                        self.wps.retain(|w| !w.death);
                        self.save_wps();
                        Ok(Some(format!("Удалено точек смерти: {}", n - self.wps.len())))
                    }
                    _ => Err(self.help("clear")),
                }
            }
            other => Err(match suggest(other, &SUBCOMMANDS) {
                Some(s) => format!("Неизвестная команда «{other}». Может, «{s}»? Справка: /wp help"),
                None => format!("Неизвестная команда «{other}». {}", self.help("")),
            }),
        }
    }
    fn bad_color(&self, w: &str) -> String {
        let names: Vec<&str> = COLORS.iter().map(|c| c.0).collect();
        match suggest(w, &names) {
            Some(s) => format!("Нет цвета «{w}». Может, «{s}»? Цвета: {}", color_list()),
            None => format!("Нет цвета «{w}». Цвета: {}", color_list()),
        }
    }

    // ---------- UI ----------
    fn widgets(&self) -> Vec<Widget> {
        let b = |id, l: String| Widget::Button(ButtonWidget { id, label: l });
        if let Some(w) = self.detail.and_then(|i| self.wps.get(i)) {
            return vec![
                Widget::Text(TextWidget { id: 0, text: format!("[{}] {}", label(&w.name), w.name), color: COLORS[w.color].1 }),
                Widget::Text(TextWidget { id: 0, text: format!("X {} Y {} Z {} · {}", w.x, w.y, w.z, short_dim(&w.dim)), color: 0xAAAAAA }),
                Widget::Text(TextWidget { id: 0, text: "Переименовать: в чате /wp name Новое имя".into(), color: 0xFFFF55 }),
                b(22, format!("Цвет: {}", COLORS[w.color].0)),
                b(23, "Удалить метку".into()),
                b(20, "← Назад к списку".into()),
            ];
        }
        let mut v = vec![Widget::Text(TextWidget {
            id: 0,
            text: format!("Мир: {} · /wp help — все команды", self.world_name()),
            color: 0xAAAAAA,
        })];
        if self.wps.is_empty() {
            v.push(Widget::Text(TextWidget { id: 0, text: "Меток нет. Нажмите «Добавить метку здесь» или /wp add Дом".into(), color: 0 }));
        } else {
            v.push(Widget::List(ListWidget {
                id: 1,
                rows: self
                    .wps
                    .iter()
                    .map(|w| format!("[{}] {} · {} {} {} · {} · {}", label(&w.name), w.name, w.x, w.y, w.z, short_dim(&w.dim), COLORS[w.color].0))
                    .collect(),
                selected: self.selected.map(|s| s as u32),
            }));
        }
        let b = |id, l: String| Widget::Button(ButtonWidget { id, label: l });
        v.push(b(10, "Добавить метку здесь".into()));
        if let Some(i) = self.selected.filter(|i| *i < self.wps.len()) {
            v.push(b(11, format!("Удалить выбранную ({})", self.wps[i].name)));
            v.push(b(12, format!("Цвет выбранной: {}", COLORS[self.wps[i].color].0)));
        }
        v.push(b(13, format!("Цвет новой: {}", COLORS[self.cfg.new_color].0)));
        v.push(b(18, format!("Масштаб по расстоянию: {}", on_off(self.cfg.scale))));
        v.push(b(14, format!("Размер меток: {}", SIZES[self.cfg.size as usize].0)));
        v.push(b(15, format!("Метки на экране: {}", on_off(self.cfg.show))));
        v.push(b(16, format!("Детали при наведении: {}", on_off(self.cfg.hover))));
        v.push(b(17, format!("Точки смерти: {}", on_off(self.cfg.death))));
        v
    }
    fn open_menu(&mut self) {
        self.menu_open = true;
        ui::open_screen(&Screen { title: "Метки".into(), widgets: self.widgets() });
    }
    fn refresh_ui(&mut self) {
        if self.menu_open {
            ui::open_screen(&Screen { title: "Метки".into(), widgets: self.widgets() });
        }
        ui::set_settings(&self.widgets());
    }

    // ---------- world tracking ----------
    fn stamp(&mut self, p: &game::Player, gt: u64) {
        if let Some(id) = self.active {
            if let Some(w) = self.worlds.iter_mut().find(|w| w.id == id) {
                w.dim = p.dimension.clone();
                w.x = p.x;
                w.y = p.y;
                w.z = p.z;
                w.gt = gt;
            }
            self.save_worlds();
        }
    }
    fn resolve(&mut self, p: &game::Player, gt: u64) {
        let at = (p.x, p.y, p.z);
        match match_world(&self.worlds, self.active, &p.dimension, at, gt) {
            Some(id) => {
                if self.active != Some(id) {
                    self.activate(id);
                }
            }
            None => {
                self.new_world(None, &p.dimension, at, gt);
            }
        }
        self.resolved = true;
        self.stamp(p, gt);
        self.toast = format!("Метки · {}", self.world_name());
        self.toast_until = self.tick + 80;
        self.refresh_ui();
    }

    // ---------- death points ----------
    fn track_death(&mut self, p: &game::Player) {
        let alive = p.health > 0.0;
        if !alive {
            if !self.dead && self.cfg.death {
                self.dead = true;
                let (x, y, z) = (p.x.floor() as i32, p.y.floor() as i32, p.z.floor() as i32);
                self.wps.push(Wp { name: DEATH_NAME.into(), x, y, z, dim: p.dimension.clone(), color: DEATH_COLOR, death: true });
                let deaths: Vec<usize> = self.wps.iter().enumerate().filter(|(_, w)| w.death).map(|(i, _)| i).collect();
                if deaths.len() > MAX_DEATHS {
                    self.wps.remove(deaths[0]);
                }
                self.save_wps();
                self.refresh_ui();
            }
            self.dead = true;
            return;
        }
        self.dead = false;
        // Alive (so not the death just recorded): standing within 5 blocks removes the point.
        let at = (p.x, p.y, p.z);
        let before = self.wps.len();
        self.wps.retain(|w| !near_death(at, &p.dimension, w));
        if self.wps.len() != before {
            self.selected = None;
            self.save_wps();
            self.refresh_ui();
        }
    }

    // ---------- drawing ----------
    fn draw(&mut self, p: &game::Player) {
        if !self.resolved || !self.cfg.show {
            if self.toast_until > self.tick && self.resolved {
                // toast only
            } else {
                render::set_hud(&[]);
                return;
            }
        }
        let (gw, gh) = render::gui_size();
        let gui = (gw as f64, gh as f64);
        let eye = (p.x, p.y + 1.62, p.z);
        let base = SIZES[self.cfg.size as usize].1 as f64;
        // (index in self.wps, x, y, distance, size in px)
        let mut vis: Vec<(usize, f32, f32, f64, f32)> = Vec::new();
        if self.cfg.show {
            for (i, w) in self.wps.iter().enumerate().filter(|(_, w)| w.dim == p.dimension) {
                let t = (w.x as f64 + 0.5, w.y as f64 + 1.0, w.z as f64 + 0.5);
                if let Some((sx, sy, d)) = project(eye, p.yaw as f64, p.pitch as f64, self.cfg.fov as f64, gui, t) {
                    let size = (if self.cfg.scale { base * scale_for(d) } else { base }).round() as f32;
                    let (sx, sy) = (sx.round() as f32, sy.round() as f32); // whole pixels: no shimmer
                    if sx > -size && sx < gw + size && sy > -size && sy < gh + size {
                        vis.push((i, sx, sy, d, size));
                    }
                }
            }
        }
        vis.sort_by(|a, b| b.3.partial_cmp(&a.3).unwrap()); // far first, near on top
        if vis.len() > MAX_SHOWN {
            vis.drain(..vis.len() - MAX_SHOWN);
        }
        let (cx, cy) = (gw / 2.0, gh / 2.0);
        let hovered = if self.cfg.hover {
            vis.iter()
                .enumerate()
                .rev()
                .find(|(_, (_, sx, sy, _, size))| {
                    let h = (size / 2.0).max(7.0) + 2.0;
                    (cx - sx).abs() <= h && (cy - sy).abs() <= h
                })
                .map(|(i, _)| i)
        } else {
            None
        };
        self.hovered_wp = hovered.map(|i| vis[i].0);
        let mut shapes: Vec<Shape> = Vec::new();
        for (n, (i, sx, sy, d, size)) in vis.iter().enumerate() {
            let w = &self.wps[*i];
            let rgb = COLORS[w.color].1;
            let hot = hovered == Some(n);
            let size = (*size as i32 / 2 * 2) as f32; // even, so the square centres on the pixel
            let half = size / 2.0;
            let b = if hot { 2.0 } else { 1.0 };
            shapes.push(Shape::Fill(FillShape { rect: Rect { x: sx - half - b, y: sy - half - b, w: size + 2.0 * b, h: size + 2.0 * b }, color: 0xFF000000 }));
            shapes.push(Shape::Fill(FillShape { rect: Rect { x: sx - half, y: sy - half, w: size, h: size }, color: 0xFF000000 | rgb }));
            // letters that fit: both, one, or none when the marker is tiny
            let text = if size >= 15.0 { label(&w.name) } else if size >= 9.0 { label(&w.name).chars().take(1).collect() } else { String::new() };
            if !text.is_empty() {
                shapes.push(Shape::Text(TextShape {
                    text,
                    at: Point { x: *sx, y: sy - 4.0 },
                    color: if luminance(rgb) > 140.0 { 0x000000 } else { 0xFFFFFF },
                    centered: true,
                    shadow: false,
                }));
            }
            if size >= 11.0 {
                shapes.push(Shape::Text(TextShape {
                    text: format!("{}м", d.round() as i64),
                    at: Point { x: *sx, y: sy + half + 3.0 },
                    color: 0xFFFFFF,
                    centered: true,
                    shadow: true,
                }));
            }
        }
        if let Some(n) = hovered {
            let (i, sx, sy, d, size) = vis[n];
            let w = &self.wps[i];
            let half = size / 2.0;
            let lines = [
                (w.name.clone(), COLORS[w.color].1),
                (format!("X {} Y {} Z {}", w.x, w.y, w.z), 0xFFFFFF),
                (format!("{}м · {}", d.round() as i64, short_dim(&w.dim)), 0xAAAAAA),
            ];
            let tw = lines.iter().map(|(t, _)| render::text_width(t)).fold(0.0f32, f32::max) + 8.0;
            let th = 3.0 * 10.0 + 4.0;
            let x = (sx + half + 6.0).min(gw - tw - 2.0).max(2.0);
            let y = (sy - th / 2.0).clamp(2.0, gh - th - 2.0);
            shapes.push(Shape::Fill(FillShape { rect: Rect { x, y, w: tw, h: th }, color: 0xE0100010 }));
            for (k, (t, c)) in lines.iter().enumerate() {
                shapes.push(Shape::Text(TextShape { text: t.clone(), at: Point { x: x + 4.0, y: y + 3.0 + k as f32 * 10.0 }, color: *c, centered: false, shadow: true }));
            }
        }
        if self.toast_until > self.tick {
            shapes.push(Shape::Text(TextShape { text: self.toast.clone(), at: Point { x: gw / 2.0, y: 4.0 }, color: 0xAAAAAA, centered: true, shadow: true }));
        }
        render::set_hud(&shapes);
    }
}

fn luminance(rgb: u32) -> f64 {
    let (r, g, b) = (((rgb >> 16) & 255) as f64, ((rgb >> 8) & 255) as f64, (rgb & 255) as f64);
    0.299 * r + 0.587 * g + 0.114 * b
}
/// First word (lower-cased) and the rest.
fn split1(s: &str) -> (String, String) {
    let s = s.trim();
    match s.split_once(char::is_whitespace) {
        Some((a, b)) => (a.to_lowercase(), b.trim().to_string()),
        None => (s.to_lowercase(), String::new()),
    }
}

impl Mod for Waypoints {
    fn init() -> Result<(Self, Registration), String> {
        let cfg = get_text("cfg2").map(|s| parse_cfg(&s)).unwrap_or_default();
        let worlds = get_text("idx").map(|s| parse_worlds(&s)).unwrap_or_default();
        let m = Waypoints {
            cfg,
            worlds,
            active: None,
            wps: Vec::new(),
            in_world: false,
            joined_tick: 0,
            resolved: false,
            last_save: 0,
            dead: false,
            toast_until: 0,
            toast: String::new(),
            tick: 0,
            selected: None,
            detail: None,
            hovered_wp: None,
            menu_open: false,
            cam: Cam::default(),
        };
        ui::set_settings(&m.widgets());
        Ok((m, Registration::new().command("wp").on_tick().on_frame()))
    }

    fn tick(&mut self, tick: u64) {
        self.tick = tick;
        let Some((p, gt)) = Self::snapshot() else {
            if self.in_world {
                // left the world: forget the session; the world is re-recognised on the next join
                self.in_world = false;
                self.resolved = false;
                self.dead = false;
                render::set_hud(&[]);
            }
            return;
        };
        if !self.in_world {
            self.in_world = true;
            self.joined_tick = tick;
            self.resolved = false;
            self.dead = p.health <= 0.0;
        }
        if !self.resolved {
            if tick >= self.joined_tick + SETTLE_TICKS {
                self.resolve(&p, gt);
                self.last_save = tick;
            }
            return;
        }
        self.track_death(&p);
        if tick >= self.last_save + SAVE_EVERY {
            self.last_save = tick;
            self.stamp(&p, gt);
        }
    }

    fn frame(&mut self, seconds: f32) {
        match game::get_player() {
            Some(p) if self.in_world => {
                let q = self.cam.adjust(&p, seconds as f64);
                self.draw(&q)
            }
            _ => {}
        }
    }

    fn command(&mut self, _name: &str, args: &str) -> Result<Option<String>, String> {
        let r = self.run(args);
        self.refresh_ui();
        r
    }

    fn ui_select(&mut self, id: u32, row: u32) {
        match id {
            1 => {
                self.selected = Some(row as usize);
                self.detail = Some(row as usize); // picking a waypoint opens its settings
            }
            20 => self.detail = None,
            22 => {
                if let Some(i) = self.detail.filter(|i| *i < self.wps.len()) {
                    self.wps[i].color = (self.wps[i].color + 1) % COLORS.len();
                    self.save_wps();
                }
            }
            23 => {
                if let Some(i) = self.detail.filter(|i| *i < self.wps.len()) {
                    self.wps.remove(i);
                    self.save_wps();
                }
                self.detail = None;
                self.selected = None;
            }
            18 => {
                self.cfg.scale = !self.cfg.scale;
                self.save_cfg();
            }
            10 => {
                let c = self.cfg.new_color;
                let _ = self.add(String::new(), c, false);
            }
            11 => {
                if let Some(i) = self.selected.filter(|i| *i < self.wps.len()) {
                    self.wps.remove(i);
                    self.selected = None;
                    self.save_wps();
                }
            }
            12 => {
                if let Some(i) = self.selected.filter(|i| *i < self.wps.len()) {
                    self.wps[i].color = (self.wps[i].color + 1) % COLORS.len();
                    self.save_wps();
                }
            }
            13 => {
                self.cfg.new_color = (self.cfg.new_color + 1) % COLORS.len();
                self.save_cfg();
            }
            14 => {
                self.cfg.size = (self.cfg.size + 1) % 3;
                self.save_cfg();
            }
            15 => {
                self.cfg.show = !self.cfg.show;
                self.save_cfg();
            }
            16 => {
                self.cfg.hover = !self.cfg.hover;
                self.save_cfg();
            }
            17 => {
                self.cfg.death = !self.cfg.death;
                self.save_cfg();
            }
            _ => {}
        }
        self.refresh_ui();
    }
    fn ui_closed(&mut self) {
        self.menu_open = false;
        self.detail = None;
    }
    fn ui_settings_opened(&mut self) {
        ui::set_settings(&self.widgets());
    }
}

horizon_mod_sdk::export_mod!(Waypoints);
