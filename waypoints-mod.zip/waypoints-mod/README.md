# Метки (Waypoints) 1.3.0 — исходники

Сборка (на компьютере с Rust и доступом к интернету):

    rustup target add wasm32-unknown-unknown
    cargo install --git https://github.com/Vasysik/horizon-android --branch android cargo-horizon-mod
    cargo horizon-mod build        # -> target/horizon-mod/waypoints.hmod

Если крейт SDK из git не подтянется, в Cargo.toml укажите path на crates/horizon-mod-sdk из клона репозитория.
Логика без SDK проверяется так: `rustc --edition 2021 --test src/logic.rs -o t && ./t`.
Команды: /wp help
